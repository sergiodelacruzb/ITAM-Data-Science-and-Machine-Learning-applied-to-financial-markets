# Módulo 2: Estadística y probabilidad con python

![](https://avatars0.githubusercontent.com/u/40369113?s=400&u=c967732f5ac2ebb5ba45840ed884c34c8cbbb3df&v=4)

Los participantes se familiarizarán con las principales áreas de conocimiento
para fortalecer su capacidad de elaborar modelos avanzados y
matemáticamente rigurosos mediante el lenguaje de programación python
